horizontal-portfolio-layout
===========================

Demo for my blog post "Horizontal Portfolio Layout with CSS3 Animations and jQuery" http://blog.sarasoueidan.com/horizontal-portfolio-layout/
